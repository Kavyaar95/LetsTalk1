package com.niit.LetsTalkBackend.Controller;

import java.util.List;

import javax.servlet.http.HttpSession;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import com.niit.LetsTalkBackend.Model.Error;
import com.niit.LetsTalkBackend.Dao.FriendDao;
import com.niit.LetsTalkBackend.Model.Friend;
import com.niit.LetsTalkBackend.Model.User;
@Controller
public class FriendController {
	Logger logger = LoggerFactory.getLogger(this.getClass());
	@Autowired
	private FriendDao friendDao;

		public FriendDao getFriendDao() {
			return friendDao;
		}

		public void setFriendDao(FriendDao friendDao) {
			this.friendDao = friendDao;
		}
	@RequestMapping(value="/getAllFriends",method=RequestMethod.GET)
		public ResponseEntity<?> getAllFriends(HttpSession session){
			User user=(User)session.getAttribute("user");
			if(user!=null){
			List<Friend> friends=friendDao.getAllFriends(user.getUsername());
			return new ResponseEntity<List<Friend>>(friends,HttpStatus.OK);
			}
			else
				return new ResponseEntity<Error>(new Error(1,"Unauthorized user"),HttpStatus.UNAUTHORIZED);
		}
	@RequestMapping(value="/friendRequest",method=RequestMethod.POST)
	public ResponseEntity<?> sendFriendRequest(@RequestBody String username,HttpSession session){
		User user=(User) session.getAttribute("user");
		if(user==null)
			return new ResponseEntity<Error>(new Error(1,"Unauthorized user"),HttpStatus.UNAUTHORIZED);
		else{
			friendDao.sendFriendRequest(user.getUsername(),username);
			return new ResponseEntity<Void>(HttpStatus.OK);
		}
	}
	@RequestMapping(value="/pendingRequest",method=RequestMethod.GET)
	public ResponseEntity<?> getAllPendingRequest(HttpSession session){
		System.out.println("ffffffffffffff1");
		User user=(User)session.getAttribute("user");
		System.out.println("ffffffffffffff1");
		logger.debug("Entering friendCONTROLLER : f");
		if(user==null)
			return new ResponseEntity<Error>(new Error(2,"Unauthorized user"),HttpStatus.UNAUTHORIZED);
		else{
			logger.debug("Entering friendCONTROLLER2 : f");
			System.out.println("ffffffffffffff");
			List<Friend> pendingRequest=friendDao.getPendingRequest(user.getUsername());
			logger.debug("Entering USERCONTROLLER : f");
			System.out.println("ffffffffffffff");
			return new ResponseEntity<List<Friend>>(pendingRequest,HttpStatus.OK);
		}
	}
	@RequestMapping(value="/updateFriendRequest/{friendStatus}/{fromId}",method=RequestMethod.PUT)
	public ResponseEntity<?> updatePendingRequest(@PathVariable(value="friendStatus") char friendStatus,
			@PathVariable(value="fromId") String fromId,HttpSession session){
		User user=(User)session.getAttribute("user");
		if(user==null)
			return new ResponseEntity<Error>(new Error(1,"Unauthorized user"),HttpStatus.UNAUTHORIZED);
		else{
			friendDao.updatePendingRequest(friendStatus,fromId,user.getUsername());
			return new ResponseEntity<Void>(HttpStatus.OK);
		}
	}
	}